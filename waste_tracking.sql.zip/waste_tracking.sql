-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2025 at 03:51 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `waste_tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jasa_pengangkutan`
--

CREATE TABLE `jasa_pengangkutan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_jasa` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jasa_pengangkutan`
--

INSERT INTO `jasa_pengangkutan` (`id`, `nama_jasa`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'Jasa Angkut Limbah A', 'Jasa pengangkutan limbah umum', '2025-11-06 08:21:19', '2025-11-06 08:21:19'),
(2, 'Angkut Sampah', 'Jasa pengangkutan sampah', '2025-11-06 08:37:14', '2025-11-06 08:37:14');

-- --------------------------------------------------------

--
-- Table structure for table `kendaraan`
--

CREATE TABLE `kendaraan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `perusahaan_id` bigint(20) UNSIGNED NOT NULL,
  `no_polisi` varchar(255) NOT NULL,
  `jenis` varchar(255) DEFAULT NULL,
  `merk` varchar(255) DEFAULT NULL,
  `kapasitas` decimal(10,2) DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kendaraan`
--

INSERT INTO `kendaraan` (`id`, `perusahaan_id`, `no_polisi`, `jenis`, `merk`, `kapasitas`, `aktif`, `created_at`, `updated_at`) VALUES
(1, 1, 'B1234XY', 'Truk Box', 'Isuzu', 10.50, 1, '2025-11-06 08:21:30', '2025-11-06 08:21:30'),
(4, 2, 'B2345YZ', 'Pickup', 'Mitsubishi', 3.50, 1, '2025-11-06 08:45:27', '2025-11-06 08:45:27'),
(5, 3, 'B3456ZX', 'Truk Engkel', 'Hino', 7.00, 1, '2025-11-06 08:45:27', '2025-11-06 08:45:27');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi_kendaraan`
--

CREATE TABLE `lokasi_kendaraan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kendaraan_id` bigint(20) UNSIGNED NOT NULL,
  `lat` decimal(10,7) NOT NULL,
  `lng` decimal(10,7) NOT NULL,
  `speed` double(8,2) DEFAULT NULL,
  `recorded_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lokasi_kendaraan`
--

INSERT INTO `lokasi_kendaraan` (`id`, `kendaraan_id`, `lat`, `lng`, `speed`, `recorded_at`, `created_at`, `updated_at`) VALUES
(1, 1, -4.7222908, 104.5436649, NULL, '2025-11-07 02:08:07', '2025-11-06 19:08:07', '2025-11-06 19:08:07');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(10, '2014_10_12_000000_create_users_table', 1),
(11, '2014_10_12_100000_create_password_resets_table', 1),
(12, '2019_08_19_000000_create_failed_jobs_table', 1),
(13, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(14, '2025_11_06_062344_create_perusahaans_table', 1),
(15, '2025_11_06_062403_create_jasa_pengangkutans_table', 1),
(16, '2025_11_06_062428_create_kendaraans_table', 1),
(17, '2025_11_06_062447_create_pengangkutans_table', 1),
(18, '2025_11_06_062514_create_lokasi_kendaraans_table', 1),
(19, '2025_11_06_064144_create_trackings_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengangkutan`
--

CREATE TABLE `pengangkutan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `perusahaan_id` bigint(20) UNSIGNED NOT NULL,
  `kendaraan_id` bigint(20) UNSIGNED NOT NULL,
  `jasa_id` bigint(20) UNSIGNED NOT NULL,
  `tanggal_pengangkutan` date NOT NULL,
  `asal` text NOT NULL,
  `tujuan` text NOT NULL,
  `status` enum('dijadwalkan','berjalan','selesai','dibatalkan') NOT NULL DEFAULT 'dijadwalkan',
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengangkutan`
--

INSERT INTO `pengangkutan` (`id`, `perusahaan_id`, `kendaraan_id`, `jasa_id`, `tanggal_pengangkutan`, `asal`, `tujuan`, `status`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, '2025-11-06', 'Gudang A', 'TPA B', 'dijadwalkan', 'Percobaan 1', '2025-11-06 08:44:00', '2025-11-06 08:44:00'),
(6, 1, 4, 1, '2025-11-06', 'Gudang B', 'TPA C', 'dijadwalkan', 'Pengangkutan percobaan 2', '2025-11-06 08:49:45', '2025-11-06 08:49:45'),
(7, 1, 5, 1, '2025-11-06', 'Gudang C', 'TPA D', 'dijadwalkan', 'Pengangkutan percobaan 3', '2025-11-06 08:49:45', '2025-11-06 08:49:45');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `perusahaan`
--

CREATE TABLE `perusahaan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` text DEFAULT NULL,
  `no_izin` varchar(255) DEFAULT NULL,
  `kontak` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `perusahaan`
--

INSERT INTO `perusahaan` (`id`, `nama`, `alamat`, `no_izin`, `kontak`, `email`, `created_at`, `updated_at`) VALUES
(1, 'PT Contoh Bersih', 'Jl. Contoh No.1, Tangerang', 'IZIN-2025-001', '08123456789', 'admin@contoh.co.id', '2025-11-06 08:20:00', '2025-11-06 08:20:00'),
(2, 'PT Bersih Jaya', 'Jl. Kebersihan No.10, Tangerang', 'IZIN-2025-001', '08123456789', 'admin@bersihjaya.co.id', '2025-11-06 08:38:50', '2025-11-06 08:38:50'),
(3, 'PT Hijau Lestari', 'Jl. Ramah Lingkungan No.5, Tangerang', 'IZIN-2025-002', '08129876543', 'info@hijau.co.id', '2025-11-06 08:38:50', '2025-11-06 08:38:50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jasa_pengangkutan`
--
ALTER TABLE `jasa_pengangkutan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kendaraan`
--
ALTER TABLE `kendaraan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kendaraan_no_polisi_unique` (`no_polisi`),
  ADD KEY `kendaraan_perusahaan_id_foreign` (`perusahaan_id`);

--
-- Indexes for table `lokasi_kendaraan`
--
ALTER TABLE `lokasi_kendaraan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lokasi_kendaraan_kendaraan_id_foreign` (`kendaraan_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `pengangkutan`
--
ALTER TABLE `pengangkutan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengangkutan_perusahaan_id_foreign` (`perusahaan_id`),
  ADD KEY `pengangkutan_kendaraan_id_foreign` (`kendaraan_id`),
  ADD KEY `pengangkutan_jasa_id_foreign` (`jasa_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `perusahaan`
--
ALTER TABLE `perusahaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jasa_pengangkutan`
--
ALTER TABLE `jasa_pengangkutan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `kendaraan`
--
ALTER TABLE `kendaraan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lokasi_kendaraan`
--
ALTER TABLE `lokasi_kendaraan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `pengangkutan`
--
ALTER TABLE `pengangkutan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `perusahaan`
--
ALTER TABLE `perusahaan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kendaraan`
--
ALTER TABLE `kendaraan`
  ADD CONSTRAINT `kendaraan_perusahaan_id_foreign` FOREIGN KEY (`perusahaan_id`) REFERENCES `perusahaan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lokasi_kendaraan`
--
ALTER TABLE `lokasi_kendaraan`
  ADD CONSTRAINT `lokasi_kendaraan_kendaraan_id_foreign` FOREIGN KEY (`kendaraan_id`) REFERENCES `kendaraan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pengangkutan`
--
ALTER TABLE `pengangkutan`
  ADD CONSTRAINT `pengangkutan_jasa_id_foreign` FOREIGN KEY (`jasa_id`) REFERENCES `jasa_pengangkutan` (`id`),
  ADD CONSTRAINT `pengangkutan_kendaraan_id_foreign` FOREIGN KEY (`kendaraan_id`) REFERENCES `kendaraan` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pengangkutan_perusahaan_id_foreign` FOREIGN KEY (`perusahaan_id`) REFERENCES `perusahaan` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
